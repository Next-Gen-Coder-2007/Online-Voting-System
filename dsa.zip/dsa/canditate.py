
class Candidate:
    def __init__(self, name, party, votes=0):
        self.name = name
        self.party = party
        self.votes = votes

    def add_vote(self):
        self.votes += 1

    def to_dict(self):
        return {
            "name": self.name,
            "party": self.party,
            "votes": self.votes
        }