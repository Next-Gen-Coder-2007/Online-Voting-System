import datetime
from voter import Voter
from canditate import Candidate
import json, os
import hashlib

class VotingSystem:
    def __init__(self):
        self.voters = {}
        self.candidates = {}
        self.vote_chain = []
        self.admin_credentials = {"admin": "password123"}
        self.load_data()

    def calculate_age(self, dob):
        birth_year = int(dob.split('/')[2])
        current_year = datetime.datetime.now().year
        return current_year - birth_year

    def add_voter(self, voter_id, name, dob, phone):
        if len(voter_id) > 16:
            return "Voter ID cannot exceed 16 characters."
        if len(phone) != 10:
            return "Phone number must be 10 digits."
        if self.calculate_age(dob) < 18:
            return "Voter must be at least 18 years old."
        if voter_id in self.voters:
            return "Voter ID already registered."
        self.voters[voter_id] = Voter(voter_id, name, dob, phone)
        self.save_data()
        return "Voter added successfully."

    def edit_voter(self, voter_id, name, dob, phone):
        if voter_id in self.voters:
            self.voters[voter_id] = Voter(voter_id, name, dob, phone, self.voters[voter_id].has_voted)
            self.save_data()
            return "Voter edited successfully."
        return "Voter not found."

    def remove_voter(self, voter_id):
        if voter_id in self.voters:
            del self.voters[voter_id]
            self.save_data()

    def add_candidate(self, name, party):
        self.candidates[name] = Candidate(name, party)
        self.save_data()

    def edit_candidate(self, name, new_name, party):
        if name in self.candidates:
            candidate = self.candidates.pop(name)
            candidate.name = new_name
            candidate.party = party
            self.candidates[new_name] = candidate
            self.save_data()
            return "Candidate edited successfully."
        return "Candidate not found."

    def remove_candidate(self, name):
        if name in self.candidates:
            del self.candidates[name]
            self.save_data()

    def cast_vote(self, voter_id, candidate_name):
        if voter_id not in self.voters:
            return "Voter not registered."

        voter = self.voters[voter_id]
        if voter.has_voted:
            return "Vote already cast."

        if candidate_name not in self.candidates:
            return "Candidate not found."

        self.candidates[candidate_name].add_vote()
        voter.has_voted = True

        vote_hash = hashlib.sha256(f"{voter_id}{candidate_name}".encode()).hexdigest()
        self.vote_chain.append(vote_hash)
        
        self.save_data()
        return "Vote cast successfully."

    def display_results(self):
        return {name: candidate.votes for name, candidate in self.candidates.items()}

    def get_voter_info(self):
        return self.voters

    def get_candidate_info(self):
        return self.candidates

    def save_data(self):
        with open('voting_data.json', 'w') as file:
            json.dump({
                "voters": {voter_id: voter.to_dict() for voter_id, voter in self.voters.items()},
                "candidates": {name: candidate.to_dict() for name, candidate in self.candidates.items()}
            }, file)

    def load_data(self):
        if os.path.exists('voting_data.json'):
            with open('voting_data.json', 'r') as file:
                data = json.load(file)
                self.voters = {voter_id: Voter(**voter_data) for voter_id, voter_data in data["voters"].items()}
                self.candidates = {name: Candidate(name=candidate_data['name'], party=candidate_data['party'], votes=candidate_data['votes']) for name, candidate_data in data["candidates"].items()}

    def get_sorted_voter_ids(self):
        return sorted(self.voters.keys())

    def binary_search_voter(self, voter_id):
        sorted_voter_ids = self.get_sorted_voter_ids()
        left, right = 0, len(sorted_voter_ids) - 1

        while left <= right:
            mid = (left + right) // 2
            mid_voter_id = sorted_voter_ids[mid]

            if mid_voter_id == voter_id:
                return self.voters[mid_voter_id]
            elif mid_voter_id < voter_id:
                left = mid + 1
            else:
                right = mid - 1

        return None
