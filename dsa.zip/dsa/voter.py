import random

class Voter:
    def __init__(self, voter_id, name, dob, phone, has_voted=False):
        self.voter_id = voter_id
        self.name = name
        self.dob = dob
        self.phone = phone
        self.has_voted = has_voted

    def generate_otp(self):
        return random.randint(1000, 9999)

    def to_dict(self):
        return {
            "voter_id": self.voter_id,
            "name": self.name,
            "dob": self.dob,
            "phone": self.phone,
            "has_voted": self.has_voted
        }